import math
a = 1
b = 9
c = 10
n = 10
h = (b-a)/n
print("x\tF(x)")
for i in range(n+1):
    x = a+ i*h
    if x <= 2*math.sqrt(2):
        print(f"{x:.2f}\tUndefined")
    else:
        result = 3 * math.sqrt(x ** 2 - 8) / x - 1
        print(f"{x:.2f}\t{result:.2f}")