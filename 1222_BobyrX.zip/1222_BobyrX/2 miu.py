import math
x = 2
y = 3
z = 4

a = 2**y**x + (3**x)**y-y*(math.atan(z)- math.pi/6) / abs(x) + 1/y**2+1
print (a)