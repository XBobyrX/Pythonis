import math
import random
a=25
b=115
c=288
print(a+b)
print(a*b)
print(a**b)
print(math.factorial(a))
print(math.sqrt(b))
print(math.gamma(a))
print(math.sin(c))
print(math.radians(a*c))
print(math.exp(a))
# import math
# a=int(input("Введите значение a="))
# z1=2*math.sin(3*math.pi-2*a)**2*math.cos(5*math.pi+2*a)**2
# z2=1/4-1/4*math.sin(5/2*math.pi-8*a)
# print(f'z1={z1}')
# print(f'z2={z2}')
import math
a=int(input("Введите значение a="))
z1=math.cos(a)+math.sin(a)+math.cos(3*a)+math.sin(3*a)
z2=2* math.sqrt(2)*math.cos(a)*math.sin(math.pi/4+2*a)
print(f'z1={z1}')
print(f'z2={z2}')
# import math
# z = int(input())
# if z < -1:
#     x = -z/3
# else:
#     x = abs(z)
# y = math.log(x + 0.5) + (math.exp(x) - math.exp(-x))
# print(y)
x = int(input("x = "))
y = int(input("y = "))
z = int(input("z = "))
m = (min(z,x) + min(x, y))/max(x,y,z) ** 2
print(m)

if z < x:
    min1 = z
else: min1 = x
if x < y:
    min2 = x
else: min2 = y
if y>x and y>z:
    max1 = y
elif x>y and x>z:
    max1 = x
elif z>x and z>y:
    max1 = z
m1 = (min1+min2)/max1 ** 2
print(m1)