# a = int(input("Введите натуральное число: "))
# b = 0
# c = 0
# while a > 0:
#     digit = a % 10
#     if digit % 2 == 0:
#         b += 1
#     else:
#         c += 1
#     a //= 10
# print("Количество четных цифр:", b)
# print("Количество нечетных цифр:", c)

a = int(input("Введите натуральное число: "))
b = 0
c = 0
d = 0
e = 1
while a > 0:
    digit = a % 10
    if digit % 2 == 0:
        b += 1
    else:
        c += 1
    d += digit
    e *= digit
    a //= 10
print("Количество четных цифр:", b)
print("Количество нечетных цифр:", c)
print("Сумма цифр числа:", d)
print("Произведение цифр числа:", e)

a = input('Введите слова: ').split()
b = set("аео")
c = []
for word in a:
    if all(letter in b for letter in word) and len(set(word)) == 3:
        c.append(word)
if c:
    print("".join(c))
else:
    print("нет")