# import telebot
# bot = telebot.TeleBot('5803414460:AAG3CxAPBe4kOUL9bl98kpubCvQqZwPKCVo')
# @bot.message_handler(commands=["start"])
# def start(m, res=False):
#     bot.send_message(m.chat.id, 'Привет солнышко. Напиши мне )')
# @bot.message_handler(content_types=["text"])
# def handle_text(message):
#     bot.send_message(message.chat.id, 'Написали: ' + message.text)
#
# bot.polling(none_stop=True, interval=0)




import telebot
import random
#
# bot = telebot.TeleBot('5803414460:AAG3CxAPBe4kOUL9bl98kpubCvQqZwPKCVo')
#
# colors=['Мятный','Красный','Белый','Чёрный','Жёлтый','Зелёный','Фиолетовый','Оранжевый','Розовый']
# colorsreturn=[]
# for item in colors:
#     colorsreturn.append(item)
#
# str=''
#
# item=''
#
#
# @bot.message_handler(commands=["start"])
# def start(m, res=False):
#     bot.send_message(m.chat.id, 'Нажмите 1 Будет любой цвет:\nНажмите 2 добавить элемент:\nНажмите 3 '
#     ' удалить элемент:')
#
#
# @bot.message_handler(content_types=["text"])
# def handle_text(message):
#     if message.text == '1':
#         bot.send_message(message.chat.id, 'Любой цвет: ' + RandomElement())
#     if message.text == '2':
#         bot.send_message(message.chat.id, 'Напишите цвет ')
#         bot.register_next_step_handler(message,AddElement)
#     if message.text == '3':
#         bot.send_message(message.chat.id, 'Напишите цвет, который надо удалить')
#         bot.register_next_step_handler(message, RemoveElement)
#
# def RandomElement():
#     if len(colorsreturn)!=0:
#         index = random.randint(0, len(colorsreturn) - 1)
#         str = colorsreturn[index]
#         colorsreturn.remove(colorsreturn[index])
#         return str
#     else:
#         for item in colors:
#             colorsreturn.append(item)
#         index = random.randint(0, len(colorsreturn) - 1)
#         str = colorsreturn[index]
#         colorsreturn.remove(colorsreturn[index])
#         return str
#
# def AddElement(message):
#     global item
#     item=message.text
#     if not colors.__contains__(item):
#         colors.append(item)
#         colorsreturn.append(item)
#         bot.send_message(message.from_user.id, f'Добавила цвет {message.text}');
#     else:
#         bot.send_message(message.chat.id, f'Цвет {message.text} существует, напишите новый')
#         bot.register_next_step_handler(message,AddElement)
#
# def RemoveElement(message):
#     global item
#     item = message.text
#     if colors.__contains__(item):
#         colors.remove(item)
#         colorsreturn.remove(item)
#         bot.send_message(message.from_user.id, f'Удалить цвет {message.text}');
#     else:
#         bot.send_message(message.from_user.id, f'Такого цвета не существует в нашем списке, я добавлю?(Скажите да)');
#         bot.register_next_step_handler(message, AddElement)
#
# bot.polling(none_stop=True, interval=0)

photki = ['https://aquazoom.ru/other/images/1059.jpg',
          'https://cs7.pikabu.ru/post_img/big/2018/04/18/9/1524063385179113708.jpg',
          'https://colorpict.com/wp-content/gallery/lisy/lisy-1.jpg']
bot = telebot.TeleBot('5803414460:AAG3CxAPBe4kOUL9bl98kpubCvQqZwPKCVo')

@bot.message_handler(commands=["start"])
def start(m, res=False):
    bot.send_message(m.chat.id, 'Любишь лисят?\nДа/Нет')


@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text == 'Да':
        bot.send_message(message.chat.id, 'Отлично!!! Я вас тоже люблю ')
    elif message.text == 'Нет':
        bot.send_message(message.chat.id, 'Может ты посмотришь на них?')
        bot.send_photo(message.chat.id, random.choice(photki))
    else:
        bot.send_message(message.chat.id, 'Ладно...')

bot.polling(none_stop=True, interval=0)