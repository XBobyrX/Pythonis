# string = "Всем привет"
# for char in string:
#     print (char)
#
# name = "я"
# surname = "хочу кушать"
# fullname = name + " " + surname
# print(fullname)
#
# name = "Aляся"
# age = 17
# info = "name: " + name + " age: "
# str (age)
# print(info)
#
# numbers = [1,2,3,4,5]
# spells = ["eew","wwq","qwe"]
# numbers1 = [2]
# numbers2 = [1]
# print(numbers)
# print(spells)
#
# str = input()
# print(str.replace("а", "ф*"))
# count = 0
# for i in range (str.__len__()):
#     if str[i] == "а":
#         count += 1
# print(count)

list = [2, 5, 21, 63, 663, 35, 234]
max = 0
index = 0
listB = []
for i in range (list.__len__()):
    if list[i]>max:
        max = list[i]
        index = i
for i in range (index, list.__len__()):
    listB.append(list[i])
print(listB, max)

list = [2132, 22, 2, 124, 234, 19, 521]
min = 2132
index = 0
listB = []
for i in range (list.__len__()):
    if list[1]<min:
        min = list[1]
        index = 1
for i in range (index, list.__len__()):
    listB.append(list[i])
print(listB, min)